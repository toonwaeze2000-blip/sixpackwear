6PACKWEAR — first local MVP

1. Open index.html in Chrome, Edge or Safari.
2. The page works without installing anything and without Vercel.
3. This is the visual/UX foundation. Product images, real products, cart logic,
   supplier integrations and checkout can be added in the next stages.
